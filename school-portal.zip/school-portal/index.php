<?php
require 'config.php';
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $s = $pdo->prepare('SELECT * FROM users WHERE username=?');
    $s->execute([trim($_POST['username'])]);
    $u = $s->fetch();
    if ($u && password_verify($_POST['password'], $u['password'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = $u;
        header('Location: dashboard.php'); exit;
    }
    $err = 'Wrong username or password';
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="login"><form method="post" class="card"><h2>School Portal</h2>
<?php if ($err) echo '<p class="err">' . e($err) . '</p>'; ?>
<input name="username" placeholder="Username" required><input name="password" type="password" placeholder="Password" required>
<button>Login</button></form></body></html>
