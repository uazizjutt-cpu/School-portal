<?php
require 'config.php'; auth();
$staff = role() !== 'student';
if ($staff && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->prepare('INSERT INTO marks(student_id,subject,obtained,total) VALUES(?,?,?,?)')->execute([$_POST['student_id'], trim($_POST['subject']), (int)$_POST['obtained'], (int)$_POST['total']]);
    header('Location: marks.php'); exit;
}
if ($staff && isset($_GET['del'])) { $pdo->prepare('DELETE FROM marks WHERE id=?')->execute([$_GET['del']]); header('Location: marks.php'); exit; }
head('Marks / Results');
if ($staff) {
    echo "<form method='post' class='card row'><select name='student_id'>";
    foreach ($pdo->query('SELECT id,roll_no,name FROM students ORDER BY name') as $s) echo "<option value='{$s['id']}'>" . e($s['roll_no'] . ' - ' . $s['name']) . '</option>';
    echo "</select><input name='subject' placeholder='Subject' required><input name='obtained' type='number' placeholder='Obtained' required><input name='total' type='number' value='100' required><button>Add</button></form>";
}
$sql = 'SELECT m.*, s.name FROM marks m JOIN students s ON s.id=m.student_id' . ($staff ? '' : ' WHERE s.id=' . (int)my_sid()) . ' ORDER BY m.id DESC';
echo '<table><tr><th>Student</th><th>Subject</th><th>Marks</th><th>%</th>' . ($staff ? '<th></th>' : '') . '</tr>';
foreach ($pdo->query($sql) as $r) {
    echo '<tr><td>' . e($r['name']) . '</td><td>' . e($r['subject']) . "</td><td>{$r['obtained']}/{$r['total']}</td><td>" . round(100 * $r['obtained'] / max(1, $r['total'])) . '%</td>';
    if ($staff) echo "<td><a href='?del={$r['id']}'>Delete</a></td>";
    echo '</tr>';
}
echo '</table>'; foot();
