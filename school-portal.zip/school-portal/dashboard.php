<?php
require 'config.php'; auth(); head('Dashboard');
if (role() !== 'student') {
    $n = fn($t) => $pdo->query("SELECT COUNT(*) FROM $t")->fetchColumn();
    echo '<div class="stats"><div class="card">Students<br><b>' . $n('students') . '</b></div><div class="card">Notices<br><b>' . $n('notices') . '</b></div><div class="card">Unpaid fees<br><b>' . $pdo->query("SELECT COUNT(*) FROM fees WHERE status='Unpaid'")->fetchColumn() . '</b></div></div>';
} else {
    $s = $pdo->prepare("SELECT ROUND(100*SUM(status='Present')/COUNT(*)) FROM attendance WHERE student_id=?"); $s->execute([my_sid()]);
    echo '<div class="card">Your attendance: <b>' . ($s->fetchColumn() ?? 0) . '%</b></div>';
}
echo '<h3>Latest notices</h3>';
foreach ($pdo->query('SELECT * FROM notices ORDER BY id DESC LIMIT 5') as $r)
    echo '<div class="card"><b>' . e($r['title']) . '</b><br>' . nl2br(e($r['body'])) . '<br><small>' . $r['created_at'] . '</small></div>';
foot();
