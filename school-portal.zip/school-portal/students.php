<?php
require 'config.php'; auth(['admin', 'teacher']);
$admin = role() === 'admin';
if ($admin && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $d = [trim($_POST['roll_no']), trim($_POST['name']), trim($_POST['class']), trim($_POST['phone'])];
    if (!empty($_POST['id'])) {
        $pdo->prepare('UPDATE students SET roll_no=?,name=?,class=?,phone=? WHERE id=?')->execute([...$d, $_POST['id']]);
    } else {
        $pdo->prepare('INSERT INTO students(roll_no,name,class,phone) VALUES(?,?,?,?)')->execute($d);
        $sid = $pdo->lastInsertId(); // student login: username = password = roll no
        $pdo->prepare("INSERT INTO users(name,username,password,role,student_id) VALUES(?,?,?, 'student',?)")->execute([$d[1], $d[0], password_hash($d[0], PASSWORD_BCRYPT), $sid]);
    }
    header('Location: students.php'); exit;
}
if ($admin && isset($_GET['del'])) { $pdo->prepare('DELETE FROM students WHERE id=?')->execute([$_GET['del']]); header('Location: students.php'); exit; }
$edit = ['id' => '', 'roll_no' => '', 'name' => '', 'class' => '', 'phone' => ''];
if ($admin && isset($_GET['edit'])) { $s = $pdo->prepare('SELECT * FROM students WHERE id=?'); $s->execute([$_GET['edit']]); $edit = $s->fetch() ?: $edit; }
head('Students');
if ($admin) { ?>
<form method="post" class="card row"><input type="hidden" name="id" value="<?= e($edit['id']) ?>">
<input name="roll_no" placeholder="Roll no" value="<?= e($edit['roll_no']) ?>" required><input name="name" placeholder="Name" value="<?= e($edit['name']) ?>" required>
<input name="class" placeholder="Class" value="<?= e($edit['class']) ?>" required><input name="phone" placeholder="Phone" value="<?= e($edit['phone']) ?>">
<button><?= $edit['id'] ? 'Update' : 'Add' ?> student</button></form>
<?php } ?>
<table><tr><th>Roll</th><th>Name</th><th>Class</th><th>Phone</th><?= $admin ? '<th></th>' : '' ?></tr>
<?php foreach ($pdo->query('SELECT * FROM students ORDER BY class, roll_no') as $r) {
    echo '<tr><td>' . e($r['roll_no']) . '</td><td>' . e($r['name']) . '</td><td>' . e($r['class']) . '</td><td>' . e($r['phone']) . '</td>';
    if ($admin) echo "<td><a href='?edit={$r['id']}'>Edit</a> <a href='?del={$r['id']}' onclick=\"return confirm('Delete?')\">Delete</a></td>";
    echo '</tr>';
} ?></table>
<?php foot();
