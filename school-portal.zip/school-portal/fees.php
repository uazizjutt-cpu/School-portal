<?php
require 'config.php'; auth();
$admin = role() === 'admin';
if ($admin && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->prepare('INSERT INTO fees(student_id,month,amount) VALUES(?,?,?)')->execute([$_POST['student_id'], trim($_POST['month']), (int)$_POST['amount']]);
    header('Location: fees.php'); exit;
}
if ($admin && isset($_GET['paid'])) { $pdo->prepare("UPDATE fees SET status='Paid' WHERE id=?")->execute([$_GET['paid']]); header('Location: fees.php'); exit; }
head('Fees');
if ($admin) {
    echo "<form method='post' class='card row'><select name='student_id'>";
    foreach ($pdo->query('SELECT id,roll_no,name FROM students ORDER BY name') as $s) echo "<option value='{$s['id']}'>" . e($s['roll_no'] . ' - ' . $s['name']) . '</option>';
    echo "</select><input name='month' placeholder='Month (e.g. Oct 2026)' required><input name='amount' type='number' placeholder='Amount' required><button>Add fee</button></form>";
}
if (role() === 'teacher') exit('Access denied');
$sql = 'SELECT f.*, s.name FROM fees f JOIN students s ON s.id=f.student_id' . ($admin ? '' : ' WHERE s.id=' . (int)my_sid()) . ' ORDER BY f.id DESC';
echo '<table><tr><th>Student</th><th>Month</th><th>Amount</th><th>Status</th>' . ($admin ? '<th></th>' : '') . '</tr>';
foreach ($pdo->query($sql) as $r) {
    echo '<tr><td>' . e($r['name']) . '</td><td>' . e($r['month']) . "</td><td>{$r['amount']}</td><td>{$r['status']}</td>";
    if ($admin) echo '<td>' . ($r['status'] === 'Unpaid' ? "<a href='?paid={$r['id']}'>Mark paid</a>" : '') . '</td>';
    echo '</tr>';
}
echo '</table>'; foot();
