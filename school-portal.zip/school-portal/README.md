# School Portal (PHP + MySQL)

Role-based school management portal with Admin, Teacher and Student logins.

## Features
- Login system (admin / teacher / student) with hashed passwords
- Student records: add, edit, delete (admin)
- Attendance (teachers mark, students view their own)
- Marks / results
- Fee management (admin adds fees and marks them paid)
- Notices / announcements

## Setup
1. Install XAMPP (or any PHP 8+ and MySQL setup) and copy this folder into `htdocs/`.
2. Import `database.sql` in phpMyAdmin.
3. Check DB credentials in `config.php`.
4. Open `http://localhost/school-portal/`.

Default admin login: `admin` / `admin123` (change it after first login).
Student accounts are created automatically when admin adds a student: username and password = roll number.

## Tech
PHP 8, MySQL (PDO prepared statements), HTML/CSS.
