<?php
session_start();
$pdo = new PDO('mysql:host=localhost;dbname=school_portal;charset=utf8mb4', 'root', '', [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function auth(array $roles = []) {
    if (empty($_SESSION['user'])) { header('Location: index.php'); exit; }
    if ($roles && !in_array($_SESSION['user']['role'], $roles)) { http_response_code(403); exit('Access denied'); }
}
function role() { return $_SESSION['user']['role'] ?? ''; }
function my_sid() { return $_SESSION['user']['student_id'] ?? 0; }
function head($title) {
    $links = ['dashboard.php' => 'Dashboard', 'notices.php' => 'Notices', 'attendance.php' => 'Attendance', 'marks.php' => 'Marks', 'fees.php' => 'Fees'];
    if (role() !== 'student') $links = ['dashboard.php' => 'Dashboard', 'students.php' => 'Students'] + array_slice($links, 1);
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . e($title) . ' - School Portal</title><link rel="stylesheet" href="assets/style.css"></head><body><nav><b>School Portal</b>';
    foreach ($links as $f => $l) echo "<a href='$f'>$l</a>";
    echo '<span>' . e($_SESSION['user']['name']) . ' (' . role() . ') <a href="logout.php">Logout</a></span></nav><main><h2>' . e($title) . '</h2>';
}
function foot() { echo '</main></body></html>'; }
