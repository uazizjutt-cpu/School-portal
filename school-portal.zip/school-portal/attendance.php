<?php
require 'config.php'; auth();
$staff = role() !== 'student';
$date = $_GET['date'] ?? date('Y-m-d');
if ($staff && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $q = $pdo->prepare('REPLACE INTO attendance(student_id,date,status) VALUES(?,?,?)');
    foreach ($_POST['status'] as $sid => $st) $q->execute([$sid, $_POST['date'], $st === 'Absent' ? 'Absent' : 'Present']);
    header('Location: attendance.php?date=' . urlencode($_POST['date'])); exit;
}
head('Attendance');
if ($staff) {
    echo "<form method='get' class='row'><input type='date' name='date' value='" . e($date) . "'><button>Go</button></form><form method='post'><input type='hidden' name='date' value='" . e($date) . "'><table><tr><th>Student</th><th>Present</th><th>Absent</th></tr>";
    $q = $pdo->prepare('SELECT s.*, a.status FROM students s LEFT JOIN attendance a ON a.student_id=s.id AND a.date=? ORDER BY class, roll_no'); $q->execute([$date]);
    foreach ($q as $r) {
        $ab = $r['status'] === 'Absent';
        echo '<tr><td>' . e($r['roll_no'] . ' - ' . $r['name']) . "</td><td><input type='radio' name='status[{$r['id']}]' value='Present'" . ($ab ? '' : ' checked') . "></td><td><input type='radio' name='status[{$r['id']}]' value='Absent'" . ($ab ? ' checked' : '') . '></td></tr>';
    }
    echo '</table><button>Save attendance</button></form>';
} else {
    $q = $pdo->prepare('SELECT date,status FROM attendance WHERE student_id=? ORDER BY date DESC'); $q->execute([my_sid()]);
    echo '<table><tr><th>Date</th><th>Status</th></tr>';
    foreach ($q as $r) echo '<tr><td>' . $r['date'] . '</td><td>' . $r['status'] . '</td></tr>';
    echo '</table>';
}
foot();
