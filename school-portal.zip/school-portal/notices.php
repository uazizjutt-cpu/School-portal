<?php
require 'config.php'; auth();
$staff = role() !== 'student';
if ($staff && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->prepare('INSERT INTO notices(title,body) VALUES(?,?)')->execute([trim($_POST['title']), trim($_POST['body'])]);
    header('Location: notices.php'); exit;
}
if (role() === 'admin' && isset($_GET['del'])) { $pdo->prepare('DELETE FROM notices WHERE id=?')->execute([$_GET['del']]); header('Location: notices.php'); exit; }
head('Notices');
if ($staff) echo "<form method='post' class='card'><input name='title' placeholder='Title' required><textarea name='body' placeholder='Notice...' required></textarea><button>Post notice</button></form>";
foreach ($pdo->query('SELECT * FROM notices ORDER BY id DESC') as $r) {
    echo '<div class="card"><b>' . e($r['title']) . '</b><br>' . nl2br(e($r['body'])) . '<br><small>' . $r['created_at'] . '</small>';
    if (role() === 'admin') echo " <a href='?del={$r['id']}'>Delete</a>";
    echo '</div>';
}
foot();
